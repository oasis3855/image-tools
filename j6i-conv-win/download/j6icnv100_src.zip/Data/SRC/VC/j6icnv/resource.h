//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by j6icnv.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_J6ICNV_DIALOG               102
#define IDR_MAINFRAME                   128
#define IDD_DLG_PROF                    129
#define IDC_TXT_FNAME                   1000
#define IDC_BTN_SEL                     1001
#define IDC_BTN_CNV                     1002
#define IDC_BTN_SHW                     1003
#define IDC_BTN_PROF                    1004
#define IDC_TXT_MES                     1007
#define IDC_BTN_SEQ                     1008
#define IDC_CHK_OVWR                    1010
#define IDC_CHK_EXT                     1011
#define IDC_TXT_EXT                     1012
#define IDC_BTN_EXT                     1013
#define IDC_CHK_PARAMVW                 1014
#define IDC_BTN_OUTPUT                  1015
#define IDC_TXT_OUTPUT                  1016
#define IDC_CHK_OUTPUT                  1017

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1018
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
