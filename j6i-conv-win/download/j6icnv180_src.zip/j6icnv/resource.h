//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by j6icnv.rc
//
#define IDC_ABOUT                       3
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_J6ICNV_DIALOG               102
#define IDS_ERR_NOFIL_OR_LONG           103
#define IDR_MAINFRAME                   128
#define IDD_DLG_PROF                    129
#define IDB_BITMAP_TITLE                133
#define IDD_DLG_INST                    134
#define IDC_TXT_FNAME                   1000
#define IDC_BTN_SEL                     1001
#define IDC_BTN_CNV                     1002
#define IDC_BTN_SHW                     1003
#define IDC_BTN_PROF                    1004
#define IDC_TXT_MES                     1007
#define IDC_BTN_SEQ                     1008
#define IDC_CHK_OVWR                    1010
#define IDC_CHK_EXT                     1011
#define IDC_TXT_EXT                     1012
#define IDC_BTN_EXT                     1013
#define IDC_CHK_PARAMVW                 1014
#define IDC_BTN_OUTPUT                  1015
#define IDC_TXT_OUTPUT                  1016
#define IDC_CHK_OUTPUT                  1017
#define IDC_CHK_NODLG                   1018
#define IDC_CHK_DELETE                  1019
#define IDC_RADIO_SELMODE_1             1019
#define IDC_RADIO_SELMODE_2             1020
#define IDC_RADIO_OUTPATH               1022
#define IDC_RADIO_OUTPATH2              1023
#define IDC_RADIO_OUTPATH3              1024
#define IDC_CHK_YEAR                    1025
#define IDC_TXT_YEAR                    1026
#define IDC_SCROLL_YEAR                 1027
#define IDC_CHK_START                   1028
#define IDC_CHK_ASSOCIATE               1029
#define IDC_RADIO_UNINST1               1030
#define IDC_RADIO_UNINST2               1031
#define IDC_HELP_INST                   1032
#define IDS_APPNAME                     57345
#define IDS_Q_UNINST                    57346
#define IDS_END_UNINST                  57347

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        136
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1033
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
